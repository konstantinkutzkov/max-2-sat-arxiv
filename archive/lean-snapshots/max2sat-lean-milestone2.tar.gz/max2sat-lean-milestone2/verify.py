#!/usr/bin/env python3
"""Build the artifact, audit proof dependencies, and record source fingerprints."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'verification'
OUT.mkdir(exist_ok=True)
(OUT / 'result.json').unlink(missing_ok=True)


def run(args, log):
    result = subprocess.run(args, cwd=ROOT, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    (OUT / log).write_text(result.stdout)
    print(result.stdout, end='', flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    return result.stdout


sources = sorted(ROOT.glob('Max2SAT/**/*.lean')) + [ROOT / 'Max2SAT.lean', ROOT / 'Audit.lean']
# The proof-dependency audit below is the primary check. This catches accidental
# placeholders and postulates in the delivered sources before the build starts.
for source in sources:
    text = source.read_text()
    if re.search(r'\b(sorry|admit)\b|^\s*(axiom|constant|unsafe)\b', text, re.MULTILINE):
        raise SystemExit(f'Forbidden placeholder or declaration in {source.relative_to(ROOT)}')

version = run(['lean', '--version'], 'toolchain.log').strip()
run(['lake', 'build', 'Max2SAT', 'Max2SAT.Examples', 'Max2SAT.Bias.Examples'], 'build.log')
audit = run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Audit.lean'], 'axioms.log')
expected = len(re.findall(r'^#print axioms ', (ROOT / 'Audit.lean').read_text(), re.MULTILINE))
records = re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", audit, re.DOTALL)
axiom_free = re.findall(r"'([^']+)' does not depend on any axioms", audit)
if len(records) + len(axiom_free) != expected:
    raise SystemExit(f'Incomplete audit: expected {expected}, parsed {len(records)+len(axiom_free)}')
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
dependencies = {}
for theorem, raw in records:
    axioms = {x.strip() for x in raw.split(',') if x.strip()}
    if not axioms <= allowed:
        raise SystemExit(f'Unexpected axioms in {theorem}: {sorted(axioms-allowed)}')
    dependencies[theorem] = sorted(axioms)
for theorem in axiom_free:
    dependencies[theorem] = []
run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Examples.lean'], 'examples.log')

run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Bias/Examples.lean'], 'bias-examples.log')

manifest = json.loads((ROOT / 'lake-manifest.json').read_text())
package_revisions = {}
for package in manifest['packages']:
    directory = ROOT / '.lake' / 'packages' / package['name']
    head = subprocess.check_output(['git', '-C', str(directory), 'rev-parse', 'HEAD'], text=True).strip()
    if head != package['rev']:
        raise SystemExit(f'Dependency revision mismatch for {package["name"]}')
    dirty = subprocess.check_output(['git', '-C', str(directory), 'status', '--porcelain'], text=True)
    if dirty:
        raise SystemExit(f'Modified dependency checkout: {package["name"]}')
    package_revisions[package['name']] = head

files = sources + [ROOT / name for name in ('lean-toolchain', 'lakefile.toml', 'lake-manifest.json', 'verify.py', 'README.md', 'verification/BIAS_PROOF.txt')]
fingerprints = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
paper = ROOT.parent / 'dense_max2sat_arxiv.tex'
report = {
    'status': 'PASS',
    'checked_at_utc': datetime.now(timezone.utc).isoformat(),
    'lean': version,
    'audited_theorems': len(dependencies),
    'allowed_standard_axioms': sorted(allowed),
    'theorem_dependencies': dependencies,
    'dependency_revisions': package_revisions,
    'source_sha256': fingerprints,
    'manuscript_reference': {'file': paper.name, 'sha256': hashlib.sha256(paper.read_bytes()).hexdigest()} if paper.exists() else None,
    'scope': 'Correctness foundation and original solver; separate fixed-preference prefix/suffix solver with verified literal-bias probability, exponential recursion-node bounds, preprocessing correctness, recursion depth and constraint representation bounds. No compiler-level bit or memory cost verification, random-instance or spectral theorem.'
}
(OUT / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(f'PASS: {len(dependencies)} audited theorems; only permitted standard axioms.', flush=True)
