import Max2SAT.IndependentPairs.Bernoulli

namespace Max2SAT.IndependentPairs.Examples
open FiniteLaw RandomInput

-- Each unordered pair appears twice in the symmetric squared-energy sum.
example : Fintype.card (Edge 2)=1 := by have h:=pair_count (n:=2); omega
example : pairEnergy (fun _ : Edge 2 => (3:ℝ))=9 := by
  have hc : Fintype.card (Edge 2)=1 := by have h:=pair_count (n:=2); omega
  norm_num [pair_energy_formula,hc]

-- Empirical centering of a single pair removes all of its row energy.
example : pairEnergy (fun _ : Edge 2 => (3:ℝ)-empiricalMean (fun _ : Edge 2 => 3))=0 := by
  have hc : Fintype.card (Edge 2)=1 := by have h:=pair_count (n:=2); omega
  norm_num [empiricalMean,pair_energy_formula,hc]

-- The first variable has no earlier neighbor, even in a nonempty graph.
example (z : Edge 3 → ℝ) : earlierEnergy z (0 : Fin 3)=0 := by simp [earlierEnergy]
example : pairEnergy (fun _ : Edge 0 => (1:ℝ))=0 := by simp [pairEnergy]

-- Max-Cut coefficients have variance 4q(1-q), including deterministic edges.
example : expect (bernoulli (1/2) (by norm_num) (by norm_num))
    (fun b => (centeredCut (1/2) b)^2)=1 := by rw [centered_cut_variance]; norm_num
example : expect (bernoulli 0 (by norm_num) (by norm_num))
    (fun b => (centeredCut 0 b)^2)=0 := by rw [centered_cut_variance]; norm_num
example : expect (bernoulli 1 (by norm_num) (by norm_num))
    (fun b => (centeredCut 1 b)^2)=0 := by rw [centered_cut_variance]; norm_num

-- Bounds are needed only on positive-mass outcomes.
example : expect (point false) (fun b => Real.exp (if b then (1000000:ℝ) else 0))≤1 := by
  have h := centered_small_mgf (point false) (fun b => if b then (1000000:ℝ) else 0) 0 0 1
    (by simp) (by intro b hb; cases b <;> simp_all [point]) (by simp) (by norm_num)
  simpa only [one_mul,mul_zero,Real.exp_zero] using h

end Max2SAT.IndependentPairs.Examples
