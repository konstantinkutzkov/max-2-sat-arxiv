#!/usr/bin/env python3
"""Build the artifact, audit proof dependencies, and record source fingerprints."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'verification'
OUT.mkdir(exist_ok=True)
(OUT / 'result.json').unlink(missing_ok=True)

# A result label alone is not enough: flag edits to the statement for a new
# mathematical correspondence review. Proof prose may be edited independently.
paper = ROOT.parent / 'dense_max2sat_arxiv.tex'
if not paper.exists():
    paper = ROOT / 'paper' / 'dense_max2sat_arxiv.tex'
if not paper.exists():
    raise SystemExit('Missing working manuscript or bundled paper snapshot')
paper_text = paper.read_text()
pattern = r'\\begin\{(lemma|theorem|corollary|proposition|target)\}(?:\[([^\]]*)\])?(.*?)\\end\{\1\}'
statements = {}
for match in re.finditer(pattern, paper_text, re.DOTALL):
    labels = re.findall(r'\\label\{([^}]*)\}', match[3])
    if not labels or labels[0] in statements:
        raise SystemExit('Missing or duplicate label on a paper result')
    normalized = ' '.join(match[0].split())
    statements[labels[0]] = hashlib.sha256(normalized.encode()).hexdigest()
correspondence = json.loads((OUT / 'paper-correspondence.json').read_text())
entries = correspondence['results']
if len({entry['paper_label'] for entry in entries}) != len(entries):
    raise SystemExit('Duplicate correspondence entries')
if {entry['paper_label'] for entry in entries} != set(statements):
    raise SystemExit('Paper result labels and correspondence entries differ')
status_counts = {}
for entry in entries:
    if entry['status'] not in {'checked', 'checked_core', 'partial', 'unverified'}:
        raise SystemExit(f'Unknown status for {entry["paper_label"]}')
    if entry['statement_sha256'] != statements[entry['paper_label']]:
        raise SystemExit(f'Review changed paper statement: {entry["paper_label"]}')
    if entry['kind'] == 'target' and (entry['status'] != 'unverified' or entry['lean_declarations']):
        raise SystemExit('A proposed research target must not be marked verified')
    if entry['status'] != 'unverified' and not entry['lean_declarations']:
        raise SystemExit(f'Missing declarations for {entry["paper_label"]}')
    status_counts[entry['status']] = status_counts.get(entry['status'], 0) + 1


def run(args, log):
    result = subprocess.run(args, cwd=ROOT, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    (OUT / log).write_text(result.stdout)
    print(result.stdout, end='', flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
    return result.stdout


sources = sorted(ROOT.glob('Max2SAT/**/*.lean')) + [ROOT / 'Max2SAT.lean', ROOT / 'Audit.lean', ROOT / 'ExternalAudit.lean']
external = json.loads((OUT / 'external-results.json').read_text())
external_ids = {item['id'] for item in external['results']}
if len(external_ids) != len(external['results']):
    raise SystemExit('Duplicate external result identifiers')
if hashlib.sha256((ROOT / external['statement_module']).read_bytes()).hexdigest() != external['statement_module_sha256']:
    raise SystemExit('Review changed formal statement of a published result')
for theorem, ids in external['conditional_declarations'].items():
    if not ids or not set(ids) <= external_ids:
        raise SystemExit(f'Invalid external dependencies for {theorem}')
for entry in entries:
    if not set(entry.get('external_dependencies', [])) <= external_ids:
        raise SystemExit(f"Unknown external dependency for {entry['paper_label']}")
# The proof-dependency audit below is the primary check. This catches accidental
# placeholders and postulates in the delivered sources before the build starts.
for source in sources:
    text = source.read_text()
    # A structure field such as `constant : ℚ` is not a postulate.
    if re.search(r'\b(sorry|admit)\b|^\s*(axiom|constant|unsafe)\b(?!\s*:)', text, re.MULTILINE):
        raise SystemExit(f'Forbidden placeholder or declaration in {source.relative_to(ROOT)}')

version = run(['lean', '--version'], 'toolchain.log').strip()
run(['lake', 'build', 'Max2SAT', 'Max2SAT.Examples', 'Max2SAT.Bias.Examples', 'Max2SAT.Random.Examples', 'Max2SAT.Random.ProbabilityExamples', 'Max2SAT.Random.ConcentrationExamples', 'Max2SAT.Random.AccumulationExamples', 'Max2SAT.Counts.Examples', 'Max2SAT.Counts.AnalyticsExamples', 'Max2SAT.Counts.RoundExamples', 'Max2SAT.Counts.CompleteExamples', 'Max2SAT.Random.RuntimeExamples', 'Max2SAT.Random.SupportExamples', 'Max2SAT.Regular.Examples', 'Max2SAT.IndependentPairs.Examples'], 'build.log')
audit = run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Audit.lean'], 'axioms.log')
expected = len(re.findall(r'^#print axioms ', (ROOT / 'Audit.lean').read_text(), re.MULTILINE))
records = re.findall(r"'([^']+)' depends on axioms:\s*\[([^\]]*)\]", audit, re.DOTALL)
axiom_free = re.findall(r"'([^']+)' does not depend on any axioms", audit)
if len(records) + len(axiom_free) != expected:
    raise SystemExit(f'Incomplete audit: expected {expected}, parsed {len(records)+len(axiom_free)}')
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
dependencies = {}
for theorem, raw in records:
    axioms = {x.strip() for x in raw.split(',') if x.strip()}
    if not axioms <= allowed:
        raise SystemExit(f'Unexpected axioms in {theorem}: {sorted(axioms-allowed)}')
    dependencies[theorem] = sorted(axioms)
for theorem in axiom_free:
    dependencies[theorem] = []
for entry in entries:
    for theorem in entry['lean_declarations']:
        if theorem not in dependencies:
            raise SystemExit(f'Unaudited declaration in correspondence: {theorem}')
external_signatures = run(['lake', 'env', 'lean', '-DwarningAsError=true', 'ExternalAudit.lean'], 'external-signatures.log')
for theorem in external['conditional_declarations']:
    if theorem not in dependencies or theorem not in external_signatures:
        raise SystemExit(f'Missing audit or signature for conditional declaration {theorem}')
run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Examples.lean'], 'examples.log')

run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Bias/Examples.lean'], 'bias-examples.log')
run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Random/Examples.lean'], 'random-examples.log')
run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Random/ProbabilityExamples.lean'], 'probability-examples.log')

run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Random/ConcentrationExamples.lean'], 'concentration-examples.log')

run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Random/AccumulationExamples.lean'], 'accumulation-examples.log')

run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Counts/Examples.lean'], 'count-examples.log')

run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Counts/AnalyticsExamples.lean'], 'count-analytics-examples.log')

run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Counts/RoundExamples.lean'], 'count-round-examples.log')

run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Counts/CompleteExamples.lean'], 'count-complete-examples.log')

run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Random/RuntimeExamples.lean'], 'runtime-examples.log')

run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Random/SupportExamples.lean'], 'support-examples.log')

run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/Regular/Examples.lean'], 'regular-examples.log')

run(['lake', 'env', 'lean', '-DwarningAsError=true', 'Max2SAT/IndependentPairs/Examples.lean'], 'independent-pairs-examples.log')

manifest = json.loads((ROOT / 'lake-manifest.json').read_text())
package_revisions = {}
for package in manifest['packages']:
    directory = ROOT / '.lake' / 'packages' / package['name']
    head = subprocess.check_output(['git', '-C', str(directory), 'rev-parse', 'HEAD'], text=True).strip()
    if head != package['rev']:
        raise SystemExit(f'Dependency revision mismatch for {package["name"]}')
    dirty = subprocess.check_output(['git', '-C', str(directory), 'status', '--porcelain'], text=True)
    if dirty:
        raise SystemExit(f'Modified dependency checkout: {package["name"]}')
    package_revisions[package['name']] = head

files = sources + [ROOT / name for name in ('lean-toolchain', 'lakefile.toml', 'lake-manifest.json', 'verify.py', 'README.md', 'verification/BIAS_PROOF.txt', 'verification/RANDOM_CORRECTNESS.txt', 'verification/RANDOM_PROBABILITY.txt', 'verification/RANDOM_EXPOSURE.txt', 'verification/RANDOM_MOMENTS.txt', 'verification/RANDOM_CONCENTRATION.txt', 'verification/RANDOM_ACCUMULATION.txt', 'verification/RANDOM_RUNTIME.txt', 'verification/RANDOM_COMPLETE.txt', 'verification/COUNT_GUESSING.txt', 'verification/COUNT_ANALYTICS.txt', 'verification/COUNT_ROUNDS.txt', 'verification/COUNT_COMPLETE.txt', 'verification/REGULAR_GRAPHS.txt', 'verification/INDEPENDENT_PAIRS_SCALAR.txt', 'verification/EXTERNAL_RESULTS.txt', 'verification/INDEPENDENT_PAIR_MEMBERSHIP.txt', 'verification/external-results.json', 'verification/paper-correspondence.json')]
fingerprints = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
report = {
    'status': 'PASS',
    'checked_at_utc': datetime.now(timezone.utc).isoformat(),
    'lean': version,
    'audited_theorems': len(dependencies),
    'allowed_standard_axioms': sorted(allowed),
    'theorem_dependencies': dependencies,
    'external_mathematical_dependencies': external,
    'dependency_revisions': package_revisions,
    'source_sha256': fingerprints,
    'manuscript_reference': {'file': paper.name, 'sha256': hashlib.sha256(paper.read_bytes()).hexdigest()},
    'paper_result_status_counts': status_counts,
    'scope': 'Paper-aligned fixed-preference literal-gap algorithm: correctness, candidate count, finite concentration, explicit exponential recursion-node bounds, preprocessing correctness, recursion depth and constraint sizes. Common reductions, pruning, checker, and exact enumeration. Polynomial bit-overhead and space use the ordinary paper argument; the dense-gap corollary has checked correctness and explicit node bounds, including its original-input preprocessing and simplicity estimates. The formula-only random-sign algorithm has checked deterministic correctness. The finite sampling models, their symmetry and second moments, and conditioning on the actual observed support are checked. The complete exposure lemma is checked: exact joint sampling law, positive-history conditional laws, actual score gains and uniform averages, initialized branching preferences, known coefficients and fresh signs, conditional mean and variance, observed-degree bounds, and later-deviation identities. The absolute-gain and second-moment lemma is checked, including general probability spaces and a finite-law measure bridge. The full finite-space conditional-range and bounded-differences lemma is checked, including adaptive pathwise budgets and zero influences. The complete accumulated-requirement and compensation inequalities are checked with their stated constants, including full-prefix instantiation, exact edge-data laws, the simpler mean argument, sensitivity and compensation budgets, and averaging over base patterns. The actual comparison-sum identity, joint feasibility bound, transfer to the original input law, and expected/high-probability candidate counts on a fixed support are checked. The random-search node and output-count connection is now checked, including rejected calls, exact initialized whole-prefix candidate counts, no duplicate outputs, and an empty-active-set boundary. Actual rational constraints, original score comparisons, preprocessing, weights, and the canonical order are identified. Fixed-support expected/high-probability node bounds and exponential bases below two are proved for supports indexed by their active vertices, including the retained-pair conditional law, with all concentration and candidate bounds discharged. The general and concrete random-input runtime theorems are checked_core: original-label active-only concentration, fixed-coordinate counts, removal of empty draws, exact conditional retained-pair laws, averaging over all observed supports, empty support, and final original-model node bounds are proved. No reindexing is required. FullRuntime proves expected nodes at most (4+6*n)*2^n*exp(-c0*n) and a (4+2*n)*2^n*exp(-c0*n/2) node threshold with failure probability at most 3*exp(-c0*n/2); ConcreteRuntime instantiates both models with the paper constants. Polynomial arithmetic and streamed space remain conventional. See RANDOM_COMPLETE.txt. The added slice lemma has direct proofs of its count-gain identity and its inequality for either polarity. Count-comparison correctness, supplied-projection correctness, explicit grid coverage, grid cardinality and allowance bounds, and the implemented accumulated-gap-plus-compensation identity are checked. The common-gap and quadratic concentration estimates are now fully proved, using finite-cube entropy with smoothing and random partition with the linear sign MGF. The manuscript contains these simpler sufficient proofs and the revised explicit fixed-round rate. Norm reductions, first moments, clipping, creator concentration, conditional block laws, compensation, profile and allowance normalization, rate substitution, and the complete per-run passing bounds are checked. The final theorems assume no probability or concentration inputs. Actual recursion-node counts across all guesses and a fixed exponential base below two are proved. Formula-level wrappers prove invariance across guesses and count preprocessing; the two-round count specialization includes its floor prefix sizes and n+1 guesses. Both projection-grid variants include their cardinality and allowance substitution. The count specialization, general accumulation theorem and grid corollary are checked_core: exactness and node counts are checked; polynomial arithmetic overhead and streamed space remain conventional paper arguments. See COUNT_COMPLETE.txt. The full hidden-community numerical wrapper and its fallback integration remain incomplete. The regular-graph corollary is checked_core: actual graph encoding and cut score, eigenvalues with multiplicity, centered operator estimate, mixing, rounded row profile, allowance, greedy independent-set completion, and the full branch-selecting node bound are proved. Fixed family thresholds give one base c<2 for all input sizes and arbitrary units. No intermediate spectral or profile estimate is assumed. See REGULAR_GRAPHS.txt. Polynomial graph conversion, arithmetic cost and streamed space are conventional; named Paley/Ramanujan constructions are not formalized. The independent-pair proposition is partial: its scalar stage is checked, and its operator-norm application is now checked conditional on two explicitly recorded published statements (Bandeira--van Handel Rademacher expectation and Ledoux convex upper tail). Symmetrization, sign insertion, independent pair geometry, Euclidean operator norms, convexity, Lipschitz contraction, incident row/column moments, the 2.89 expectation constant, 2.90 norm threshold, n^-3 failure, and the substitution from the paper density assumption are proved. The empirical perturbation, 9*chi*D normalization, and union with the scalar event are checked. The published statements are explicit hypotheses, not axioms or claimed Lean proofs. See external-results.json and EXTERNAL_RESULTS.txt; the standard-axiom audit alone does not capture this conditional scope. The subsequent finite-law membership batch completes scalar threshold substitutions, rounded row-profile summation, comparison allowance, final 1-1/n membership in both centering cases, and the count-accumulation size bound. Original-coefficient wrappers identify the actual empirical mean or supplied expectation; homogeneous empirical and inhomogeneous supplied Bernoulli graph instances are proved. No intermediate concentration, row profile or allowance bound remains an assumption. The two published matrix statements remain explicit hypotheses. See INDEPENDENT_PAIR_MEMBERSHIP.txt. The proposition remains partial solely for arbitrary non-finite laws; full SBM runtime and hidden-mean discovery/fallback remain outstanding. The appendix extension is an unproved research target. No compiler-level cost verification.'
}
(OUT / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(f'PASS: {len(dependencies)} audited theorems; only permitted standard axioms; {len(external_ids)} explicitly recorded published-result hypotheses.', flush=True)
