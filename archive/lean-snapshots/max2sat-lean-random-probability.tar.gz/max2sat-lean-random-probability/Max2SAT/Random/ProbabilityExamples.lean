import Max2SAT.Random.ObservedFormula
import Max2SAT.Random.EndpointSigns

/-! Kernel-checked regression cases for the finite sampling models and
exposure transformations. No random testing is used as proof evidence. -/
namespace Max2SAT.RandomInput.Examples
noncomputable section
open FiniteLaw

example (left : Bool) : expect oneClause (fun K => (signedCount left K)^2) = 1 :=
  oneClause_moment left

example (left : Bool) : expect (independentClauses (1/4) (by norm_num) (by norm_num))
    (fun K => (signedCount left K)^2) = 3/4 := quarter_moment left

example (left : Bool) : expect (independentClauses 0 (by norm_num) (by norm_num))
    (fun K => (signedCount left K)^2) = 0 := by
  rw [independentClauses_moment]
  norm_num

example (left : Bool) : expect (independentClauses 1 (by norm_num) (by norm_num))
    (fun K => (signedCount left K)^2) = 0 := by
  rw [independentClauses_moment]
  norm_num

example : 0 < prob oneClause present := present_positive oneClauseModel (by norm_num)

/-- Shared multiplication preserves the whole joint law, even though the
same assignment bit is used for all three endpoint signs. -/
example : push (tensor fair (fairBits (Fin 3)))
    (fun z => (z.1,multiplyBits (fun _ : Fin 3 => z.1) z.2)) =
      tensor fair (fairBits (Fin 3)) := joint_multiply (ι := Fin 3) fair (fun b _ => b)

def e01 : Edge 3 := ⟨(0,1),by decide⟩
def e12 : Edge 3 := ⟨(1,2),by decide⟩
def support : Finset (Edge 3) := {e01,e12}
def draws : support → Pattern 4 := fun e => if e.val=e01 then onePattern (true,false) else 0
def fixedUnits : List (Literal 3) := [⟨2,true⟩,⟨2,true⟩]

example : wellFormed (generate support draws fixedUnits) := generate_wellFormed _ _ _

example : (1 : Fin 3) ∈ Random.neighbors (generate support draws fixedUnits) 0 := by
  have he : e01 ∈ support := by simp [support]
  apply (generated_edge_neighbors support draws fixedUnits ⟨e01,he⟩).mpr
  simp [draws,present]

example : (2 : Fin 3) ∉ Random.neighbors (generate support draws fixedUnits) 1 := by
  have he : e12 ∈ support := by simp [support]
  apply (generated_edge_neighbors support draws fixedUnits ⟨e12,he⟩).not.mpr
  have hn : e12 ≠ e01 := by decide
  simp [draws,hn,present,size]

example : pairGain true (signedFlip (false,true) (onePattern (true,false))) true -
    signedCount true (signedFlip (false,true) (onePattern (true,false))) / 2 = -1/2 := by
  rw [endpoint_deviation]
  norm_num [eta,pairGain,signedCount,onePattern,endpoint,sign,theta,Fintype.sum_prod_type]

end
end Max2SAT.RandomInput.Examples
