import Max2SAT

/-! Show the external statements and every public theorem that accepts them.
This is separate from the standard-axiom audit. -/
#print Max2SAT.IndependentPairs.External.BandeiraVanHandel
#print Max2SAT.IndependentPairs.External.LedouxUpperTail
#check @Max2SAT.IndependentPairs.upper_rademacher_bound
#check @Max2SAT.IndependentPairs.upper_expect_from_row_moments
#check @Max2SAT.IndependentPairs.upper_expect_289
#check @Max2SAT.IndependentPairs.upper_norm_tail
#check @Max2SAT.IndependentPairs.shifted_upper_norm_tail
#check @Max2SAT.IndependentPairs.independent_pair_norm_tail
#check @Max2SAT.IndependentPairs.independent_pair_norm_from_paper
#check @Max2SAT.IndependentPairs.scalar_operator_event
#check @Max2SAT.IndependentPairs.empirical_membership
#check @Max2SAT.IndependentPairs.raw_operator_event
#check @Max2SAT.IndependentPairs.supplied_membership
#check @Max2SAT.IndependentPairs.empirical_input_membership
#check @Max2SAT.IndependentPairs.supplied_input_membership
#check @Max2SAT.IndependentPairs.bernoulli_supplied_membership
#check @Max2SAT.IndependentPairs.bernoulli_empirical_membership
#check @Max2SAT.Community.symmetric_noise_tail
