import Max2SAT.Community.Computed

namespace Max2SAT.Community.Examples
open Counts

-- The square-root routine uses rational/integer operations, including for
-- fractions and positive inputs whose square root is irrational.
example : rootBelow 4=2 := by norm_num [rootBelow]
example : rootBelow (1/4)=1/2 := by norm_num [rootBelow]
example : rootBelow 2=1 := by norm_num [rootBelow]
example : cappedSpacing 4 (-3)=1/16 := by norm_num [cappedSpacing]
example : cappedSpacing 4 (1/2)=1/2 := by norm_num [cappedSpacing]
example : (firstRound 11).card=2 ∧ (secondRound 11).card=3 := by decide

-- Check both exhaustive fallbacks and the zero-mass comparison branch.
def zeroRepresentation (n : ℕ) : Representation n 1 :=
  ⟨fun _ => 0, fun _ _ => 0, -1⟩
def onePair : Formula 4 := [.pair ⟨0,true⟩ ⟨1,false⟩]
#eval (computedResult ([] : Formula 0) 1 (fun _ => zeroRepresentation 0)).map Prod.fst
#eval (computedResult ([] : Formula 4) 1 (fun _ => zeroRepresentation 4)).map Prod.fst
#eval (computedResult onePair 1 (fun _ => zeroRepresentation 4)).map Prod.fst

-- A deliberately inaccurate representation still gives an exact search.
def inaccurate : Representation 4 1 := ⟨fun _ => 1, fun _ _ => 0, -1⟩
#eval (computedResult onePair 1 (fun _ => inaccurate)).map Prod.fst
example : ∃ q x, computedResult onePair 1 (fun _ => inaccurate)=some (q,x) ∧
    q=score onePair x ∧ ∀ y, score onePair y≤q :=
  computed_result_correct _ _ _ (by
    intro c hc
    simp only [onePair,List.mem_cons,List.not_mem_nil,or_false] at hc
    subst c
    decide)

-- Keep the Euclidean operator norm distinct from the entrywise function norm.
open scoped Matrix.Norms.L2Operator in
example (A : Matrix (Fin 4) (Fin 4) ℝ) :
    ‖offDiagonal A‖=‖Matrix.toEuclideanCLM (n:=Fin 4) (𝕜:=ℝ) (offDiagonal A)‖ := rfl

end Max2SAT.Community.Examples
