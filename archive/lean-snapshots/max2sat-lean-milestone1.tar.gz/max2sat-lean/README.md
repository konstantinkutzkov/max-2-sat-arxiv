# Max 2-SAT: Lean verification artifact

This artifact formalizes the correctness foundation and the output-sensitive
enumeration argument for the Max 2-SAT manuscript. It includes an executable,
streaming reference solver and proofs valid for every finite number of variables.
The small executable examples are additional checks, not the basis of the proofs.

**Scope:** this is not yet a formal verification of the exponential running-time
theorems. In particular, the relative-bias probability argument, random-instance
bounds, spectral arguments, and stochastic-block-model results are not included.

## Reproduce the checks

The project pins Lean `v4.34.0` and mathlib commit
`5ed2965256430c3649e86755f9576b54eca72435`. All transitive package revisions are
recorded in `lake-manifest.json`.

With [elan](https://github.com/leanprover/elan) installed, run from this directory:

```sh
lake exe cache get
python3 verify.py
```

The first command obtains precompiled mathlib dependencies and requires network
access on a fresh machine. It is unnecessary when the pinned dependencies and
their build cache are already available. `verify.py` builds the source modules,
checks the example proofs, audits the listed theorem dependencies, verifies
package revisions, and writes logs and SHA-256 source fingerprints to
`verification/`. An existing `result.json` describes the source hashes recorded
in that file; rerun the script after editing the source.

No `sorry`, `admit`, custom axiom, or `native_decide` is used in the proofs.
The audit permits only Lean's standard `propext`, `Classical.choice`, and
`Quot.sound` dependencies. Compilation of a proof is kernel checking; the `#eval`
outputs are executable examples and are not themselves proof certificates.

## Mathematical model

An assignment is a function `Fin n → Bool`. A literal contains a variable and
its polarity. A formula is a list of unit and binary clauses. Its integer-valued
score counts satisfied clauses, including multiplicity. `wellFormed` requires
two different variables in each binary clause. Thus simple formulas are covered,
and repeated clauses and the unit multiplicities created by preprocessing are
also represented correctly. There are no external hard input constraints.

A pruning constraint is a list of literal occurrences and an integer bound:

\[
  \sum_{a\in C.\mathrm{terms}} a(x)\le C.\mathrm{bound}.
\]

Repeated literals in this list really are counted repeatedly. `v.force true x`
sets the **literal** `v` to true; it does not always set its underlying variable
to true. The strict comparison cut includes the integer offset `-1`.

## Correspondence with the manuscript

The labels below refer to `dense_max2sat_arxiv.tex`. The verification report records
the hash of the manuscript used for this correspondence; it does not claim that
Lean has checked the surrounding natural-language exposition.

| Paper claim or operation | Lean declarations | What is established |
| --- | --- | --- |
| `lem:unit_canc` | `unit_cancellation` | Opposite units contribute exactly one satisfied clause. |
| `lem:simplify`, `Preprocess` | `pair_reduction`, `preprocess_correct`, `preprocess_finished` | Pair reductions and an executable exhaustive reduction loop preserve every score up to an offset; the loop reaches a fixed point. |
| `lem:unit_dom` | `unit_domination`, `safe_domination` | Unit domination and its explicit compatibility condition for inherited constraints. |
| `lem:pruning` | `pruning_gain_identity`, `pruning_bound_counts`, `pruning_iff_strict_improvement` | The occurrence-count cut is equivalent to strict improvement in the nonpreferred child. |
| Constraint propagation | `Constraint.propagation`, `remove_false`, `remove_true`, `redundant` | Multiplicity-based forcing, substitution, and deletion of tautological constraints. |
| `lem:constraint_sum` | `Constraint.holds_sum`, `normalize_iff`, `minimum_lhs`, `reject_sound` | Summation, exact complementary cancellation, an attained minimum for the summed left-hand side, and sound rejection after restriction to the current prefix. |
| Global comparison-search correctness | `ComparisonTree.winner_survives`, `comparisonTree_covers`, `comparisonTree_valid` | The earliest optimum survives all generated cuts; every complete assignment occurs in the unpruned comparison tree. |
| Correctness underlying `lem:gap_correctness` | `checkedSearch_correct`, `solve_correct`, `solvePreprocessed_correct` | An optimal original assignment is returned by the concrete reference solver, including preprocessing and the concrete sum checker. |
| `lem:enumeration` | `Enumeration.mem_enumerate`, `enumerate_nodup`, `nodes_bound`, `prefix_suffix_bound` | Exact, duplicate-free enumeration and explicit bounds that include rejected nodes. |
| Streaming implementation | `foldSearch_eq_foldl`, `Enumeration.foldEnumerate_eq_foldl`, `stackDepth_bound` | The streaming procedures visit the specified outputs; suffix enumeration has recursion depth at most `k+1`. |

All declarations in the table are in namespace `Max2SAT`; the `Constraint`,
`ComparisonTree`, and `Enumeration` declarations use nested namespaces.

## Main checked statements

For every well-formed unweighted formula `F` on `n` variables,
`solvePreprocessed_correct` proves

\[
 \exists x:\{0,1\}^n,\quad
 \mathrm{solvePreprocessed}(F)=\mathrm{some}(x)
 \quad\text{and}\quad
 \forall y:\{0,1\}^n,\;\mathrm{score}_F(y)\le\mathrm{score}_F(x).
\]

This theorem has no density assumption, no assumed soundness of the implemented
rejection test, and no unproved optimality hypothesis. Correctness does not imply
that the solver is faster than exhaustive search on arbitrary inputs.

For a nonnegative rational inequality with `k` variables and `N` satisfying
Boolean assignments, the enumerator visits at most

\[
 1+2kN
\]

nodes, counting the root and rejected children. If there are no satisfying
assignments, the negative-bound root is the only visited node. The enumerator
outputs each solution exactly once. The prefix–suffix theorem allows different
weights and bounds after each prefix and proves

\[
 \mathrm{nodes}\le 2^{T+1}-1+2k\sum_\alpha N(\alpha)
\]

when there are at most `2^T` suffix instances, each on at most `k` variables.
The prefix contribution in this theorem is explicitly defined as that of a full
binary prefix tree; its leaves are charged as the suffix roots.

The exact single-constraint feasibility theorem `Constraint.infeasible_iff` does
**not** decide feasibility of an arbitrary collection. For a collection, the
individual tests and the temporary summed-constraint test remain sufficient
conditions for rejection. Passing them is not a feasibility certificate.

## Why the global correctness proof matters

A local comparison can redirect a dominated assignment to one that violates an
older pruning constraint. The global proof does not assume otherwise. It orders
the children with the preferred child first and chooses the earliest maximum in
the complete comparison tree. If that assignment violated a newly generated cut,
an at-least-as-good assignment would occur earlier, contradicting its choice.
This establishes simultaneous compatibility of the generated cuts. The complete
tree is a proof object; the executable solver never constructs it.

## Reference implementation and its limits

`solvePreprocessed` runs the verified reduction procedure and then `solve`.
`solve` uses increasing variable labels, chooses its preferred polarity from the
restricted comparison expression, and checks individual constraints and their
sum at every recursive call. `foldSearch` keeps one best assignment instead of
storing all solutions. The proof also permits arbitrary selection of an
unassigned variable through the `Selector` interface.

The reference implementation retains the preprocessed formula when computing
comparisons and restricts its constraints to the current prefix. It is not a
line-by-line implementation of every optimization in the manuscript's
`Simplify` procedure. Propagation and guarded domination are proved separately;
the solver does not eagerly execute those optional assignment rules. The
formalized correctness mechanism and concrete checker can be reused when these
optimizations are integrated.

The following are **not** claimed by this artifact:

- An end-to-end `O*(c^n)` running-time theorem for any of the paper's input classes.
- Formalized probability estimates, martingales, spectral bounds, or random models.
- A bit-operation or machine-memory bound for the compiled program. The node-count
  and recursion-depth theorems have explicit mathematical cost models.
- Verification of a separate implementation in another language, of Lean's
  compiler, or of the manuscript's natural-language statements.
- Canonical-form graph properties beyond the proved fixed-point result for the
  implemented preprocessing rules.

## Files

Read `Basic.lean`, `Pruning.lean`, and `Reduction.lean` first. `Preprocess.lean`
contains the executable reduction loop. `ConstraintCheck.lean` and
`Normalization.lean` provide the arithmetic checker and its minimum theorem.
`Search.lean` proves the general tree argument; `Coverage.lean` instantiates it
with Boolean assignments. `Solver.lean` and `VerifiedSolver.lean` connect that
argument to an executable solver. `Enumeration.lean` is independent of the solver
and proves the enumeration bounds. `Examples.lean` contains small regressions.
All these files are under `Max2SAT/`.

`Audit.lean` lists the public theorem dependency checks. `verification/result.json`
is the machine-readable result, with build, axiom, and example logs beside it.

## Suggested description for the submission

> We provide a Lean 4 formalization of the score-preserving reductions,
> comparison-based pruning, constraint propagation and summation checks, and
> global optimality of a streaming reference solver. We also verify explicit
> output-sensitive enumeration bounds, including rejected search nodes. The
> formalization covers arbitrary finite well-formed unweighted formulas. The
> probabilistic and structural analyses establishing exponential savings are
> outside the scope of this initial artifact.
