# Lean verification for the Max 2-SAT paper

This is the active formal artifact for `dense_max2sat_arxiv.tex`. It contains the
paper's fixed-preference literal-gap algorithm and the deterministic random-formula
algorithm with preferences recomputed from residual formulas. Both use summed
pruning constraints and streaming suffix enumeration. The older adaptive
implementation is excluded from the active build and submission archive; it is
preserved locally in `archive/pre-paper-alignment/` and in the earlier milestone
archives. Supporting lemmas are retained when they justify paper statements or
procedures. They need not each become a separate numbered lemma in the paper.

## What is checked

Lean checks the score-preserving reductions, comparison constraints, arithmetic
checker, exact enumeration, simultaneous-optimum argument, finite concentration
inequality, and the literal-bias candidate and recursion-node bounds. It also
checks recursion-depth and constraint-representation bounds for the literal-gap
algorithm. For the random-formula algorithm it checks deterministic correctness,
formula-only initialization, rational weighted-sum feasibility, and exact suffix
enumeration. The finite sampling models and observed-support conditioning
lemma and the full endpoint exposure lemma are also checked.
Its probabilistic runtime guarantees remain unverified. The conventional
polynomial bit-overhead and space arguments are explained in the paper; they are
not formal machine-cost or compiler proofs.

The [correspondence record](verification/paper-correspondence.json) lists **every
numbered result and proposed theorem** in the active manuscript. Its statuses mean:

- `checked`: the stated mathematical content has corresponding checked Lean
  declarations, with the translation and scope explained in the record.
- `checked_core`: the correctness, explicit node counts, and structural resource
  bounds are checked, while the final bit-complexity implementation argument is
  ordinary mathematics in the paper.
- `partial`: useful dependencies are checked, but additional mathematical claims
  in this result remain to be formalized.
- `unverified`: no verification of the complete result is claimed.

The dense-gap corollary now has the same `checked_core` status as the relative-bias
theorem, including its preprocessing-gap preservation and simple-input occurrence
estimates. The random-formula correctness lemma is `checked`; its main runtime
theorem is `partial`, with deterministic exactness and sampling/conditioning
verified. The observed-pairs and exposure lemmas are both `checked`.
The concentration estimates and the regular-graph and stochastic-block-model results remain
unverified. The appendix extension is an unproved research target,
recorded as `unverified` with no Lean declarations. A
correspondence entry is not itself a proof of equivalence between prose and Lean;
its mathematical translation must still be reviewed.

## Reproduce the checks

The project pins Lean `v4.34.0` and mathlib commit
`5ed2965256430c3649e86755f9576b54eca72435`. All dependency revisions are recorded in
`lake-manifest.json`. With elan installed, run from this directory:

```sh
lake exe cache get
python3 verify.py
```

The cache command requires network access on a fresh machine. `verify.py` builds
the modules, checks the examples, audits theorem axioms and package revisions,
validates the correspondence labels, statement fingerprints, and declaration names, and records source
and manuscript fingerprints in `verification/result.json`. It uses the adjacent
working manuscript, or the `paper/` snapshot included in the standalone archive.
Rerun it after editing sources or the manuscript. Changed statement text requires a fresh correspondence review. These syntactic
checks cannot establish semantic equivalence between prose and formal statements.

No proof uses `sorry`, `admit`, a custom axiom, or `native_decide`. The dependency
audit allows only the standard `propext`, `Classical.choice`, and `Quot.sound`.
Executable `#eval` examples supplement the universal proofs and are not proof
certificates themselves. Results and hashes describe precisely the checked files.

## Mathematical model and algorithm correspondence

An assignment is `Fin n → Bool`. A formula is a list of unit and binary clauses;
its integer score counts satisfied copies. `wellFormed` requires two different
variables in every binary clause. The formal results therefore cover simple
inputs and the unit multiplicities produced by preprocessing; many also hold for
arbitrary repeated clauses. `Simple F` additionally requires the list of clause
literal sets to have no duplicates: reversing a binary clause does not make it
a different clause. Simplicity is required only of the original input in the
dense-gap result. The model has no external hard input constraints.

A constraint stores literal occurrences and an integer bound. An occurrence
contributes zero or one, and duplicates are counted separately. `v.force true x`
sets the literal `v` to true. The strict comparison uses an offset of minus one.
`Constraint.infeasible_iff` decides feasibility of a **single** normalized
constraint; passing the sum test does not certify joint feasibility of a
collection.

`Bias.solveBiasPreprocessed` is the paper's literal-gap algorithm. It preprocesses
`F`, computes initial preferred bits and the half carrying more total absolute
gap, branches over that half, and streams the completions satisfying each
prefix's sum. It returns an optimal original assignment; its original score can
be read with `score F`. Thus returning a score/assignment pair in the pseudocode
adds only the final score evaluation.

The Lean implementation creates cuts when processing a prefix rather than
precomputing a table of identical cuts. Its suffix recursion substitutes and
normalizes at each call. The paper's oriented nonnegative-coefficient inequality
has the same feasible completions; choosing the order of the two children does
not change the node-count bound. Both versions retain only the best assignment.
Neither assumes that a suffix must satisfy every individual cut.

The correctness theorem holds without density assumptions. Under
`Bias.RelativeBias` on the preprocessed formula and `n > 0`,
`Bias.relative_bias_preprocessed` also proves the explicit bound

\[
 \mathrm{nodes}\le(4+2n)2^{(1-\varepsilon^2\eta^2/(3000R))n}.
\]

`Bias.relative_bias_nodes` gives the stronger natural-exponential constant 512.
`Bias.exponential_base_lt_two` proves the stated base is below two. The real
parameters and witness set `S` are proof parameters, not algorithm inputs.

For the general candidate lemma, `Bias.gap_mass_output_count` proves

\[
 W\le2^n\exp\left(-G^2/(512Q)\right),\qquad
 G=\sum_i|g_i|,\quad Q=\sum_i B_i^2>0.
\]

For the dense-gap corollary, `Bias.dense_gap_preprocessed` assumes a simple
**original** formula and at least eta*n original gaps of magnitude epsilon*n.
It proves optimality and the explicit bound

\[
 \mathrm{nodes}\le(4+2n)2^{(1-\varepsilon^2\eta^2/48000)n},
\]

with the same executable algorithm. Its proof includes preservation of effective
gaps by preprocessing, nonincrease of occurrence counts, the bound
B_i <= 4(n-1)+2 for a simple input, and the resulting Q <= 16n^3 and
G >= epsilon*eta*n^2 estimates. `Bias.dense_gap_output_count` gives the
corresponding candidate bound with natural-exponential denominator 8192.
The node theorem is stated for n > 0; general solver correctness covers n=0.
`Bias.dense_gap_base_lt_two` verifies the strict saving for positive parameters.

The implementation of `Simplify` as a complete loop is not part of the checked
literal-gap algorithm. Its individual rules and the guarded domination condition
are proved separately. The literal-gap algorithm needs only preprocessing,
restriction, and complementary cancellation.

## Random-formula algorithm

`Random.randomFormula` implements the formula-only procedure in Section 4.
`Random.randomFormula_correct` proves it returns both an optimum original score
and an assignment attaining it. The theorem covers repeated clauses, unit-only
variables, empty support, and zero variables. No generating graph or randomness
is supplied to the implementation.

Its support and distinct-neighbor weights are computed before preprocessing;
its order is the sorted original labels of variables with binary occurrences.
At each prefix node it computes the preferred literal from the residual effective
gap and adds a weighted strict cut to the nonpreferred branch. It checks the
weighted sum, and at the fixed stopping depth enumerates exactly its satisfying
suffixes. The proof follows the earliest-optimum argument in `lem:exactA`.

A rational per-variable cost representation performs exact complementary
cancellation without expanding weights into repeated literals. Residuals are
recomputed from the fixed preprocessed formula, and substitution in inherited
constraints is performed when their sum is tested. Exact score and minimum
identities justify these functional representations. The executable procedure
streams candidates; its full decision tree and list of outputs are proof objects.

See [RANDOM_CORRECTNESS.txt](verification/RANDOM_CORRECTNESS.txt) for the detailed
paper-to-code correspondence and remaining probabilistic obligations. This
milestone does **not** verify the random-input exponential runtime guarantee.

## Random-input distributions and conditioning

The finite-law development proves normalization, independent product laws,
conditioning on coordinate events, and exact joint-law preservation under
random endpoint flips. A pair multiset has four bounded multiplicities.
The two concrete input models have the claimed symmetries and second moments:
1 for one uniform clause, and 4q(1-q) for four independent inclusion trials.

The sampled pair counts generate the actual `Formula` representation.
Their nonempty support is proved to coincide with `Random.neighbors` before
preprocessing, even with arbitrary fixed units. Conditioning on the observed
support preserves independence and symmetry and cannot decrease the endpoint
second moments. This completes `lem:observed_pairs`.

For `lem:random_exposure`, the full auxiliary experiment has exactly the
prescribed joint law of pair patterns and an independent uniform assignment.
The checked history determines each coefficient while leaving the required
signs fresh. The full gain, its average over unassigned values, and the
preferred value after initialization and preprocessing are connected to the
actual algorithm. Conditional mean, variance, the bound using the observed
degree, and the later-deviation identities and joint sign laws are checked.
No independence of the pruning constraints is assumed. See
[RANDOM_PROBABILITY.txt](verification/RANDOM_PROBABILITY.txt) for sampling and
conditioning, and [RANDOM_EXPOSURE.txt](verification/RANDOM_EXPOSURE.txt) for
the complete exposure correspondence and remaining obligations.

## Source organization

- `Basic`, `Pruning`, `Reduction`, and `Preprocess`: score model, comparisons,
  reductions, and the executable preprocessing procedure.
- `ConstraintCheck`, `Normalization`, and `Simplification`: substitution,
  propagation, summation, exact minimum, and guarded domination.
- `PartialAssignment` and `Enumeration`: prefix compatibility and exact
  nonnegative rational-inequality enumeration with explicit node/depth bounds.
- `Bias/FairCoin`, `Incidence`, `Moments`, `Influence`, and `Accumulation`:
  the finite concentration proof and the formula statistics it bounds.
- `Bias/Optimal`, `ConstraintEnumeration`, and `Hybrid`: the common optimum,
  exact occurrence-constraint enumeration, and streaming prefix/suffix search.
- `Bias/Parameters`, `Counting`, `Complexity`, and `Resources`: branching-set
  choice, general candidate count, relative-bias theorem, and storage bounds.
- `Bias/PreprocessStats`, `Simple`, and `DenseGap`: preprocessing statistics,
  logical-clause simplicity and its incidence bound, and the dense-gap corollary.
- `Random/Residual` and `Support`: exact formula substitution, observed support,
  unit-only optimization, and the prescribed rational weights.
- `Random/Weighted` and `WeightedEnumeration`: weighted sums, exact minimum,
  completion enumeration, and its streaming implementation.
- `Random/ComparisonTree`, `FullTree`, `Search`, and `Algorithm`: the proof's
  earliest optimum, adaptive prefix search, and the formula-only outer procedure.
- `Random/FiniteLaw`, `ProductLaw`, and `FreshBits`: finite distributions,
  conditional product laws, and independent-sign transformations.
- `Random/PairModel`, `Sampling`, `Encoding`, and `ObservedFormula`: the input
  models, their formula representation, and observed-support conditioning.
- `Random/EndpointSigns`: symmetry construction and per-edge exposure identities.
- `Random/ProductTools`, `BlockLaws`, and `SignMoments`: coordinate projections,
  exact conditional laws, and finite signed-sum moments.
- `Random/FormulaGains` and `GainAverage`: actual score differences, residual
  gaps, preprocessing preservation, and uniform-completion averages.
- `Random/ExposureGraph`, `ExposureSupport`, and `ExposureLaw`: bit indices,
  coefficients, observed degree, history transitions, and the full sampling law.
- `Random/SequentialExposure` and `Exposure`: conditional exposure results and
  their connection to the initialized formula-only algorithm.
- The four example modules: kernel-checked regressions and small executions;
  `Random/ProbabilityExamples` checks distribution and encoding cases.

`Audit.lean` lists public declarations for the transitive axiom audit. Further
supporting lemmas are checked as dependencies. See
[BIAS_PROOF.txt](verification/BIAS_PROOF.txt) for a prose guide.

The policy for subsequent work is to revise a paper statement and its formal
counterpart together, record any remaining gap explicitly, and rebuild before
reporting verification. Full coverage of the paper is a goal; the current
artifact does not claim it.
